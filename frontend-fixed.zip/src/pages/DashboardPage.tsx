/**
 * Dashboard Page - Exemplo Completo
 * 
 * Página que demonstra todos os componentes de real-time juntos.
 */

import { RealtimeTelemetryCard, RealtimeTelemetryCardCompact } from '../components/RealtimeTelemetryCard';
import { RealtimeChart } from '../components/RealtimeChart';
import { DeviceStatusGrid } from '../components/DeviceStatusGrid';

export function DashboardPage() {
  // Configuração de devices
  const devices = [
    {
      id: 'esp32s3-lab',
      name: 'ESP32-S3 Lab',
      location: 'Laboratório Principal',
      type: 'Sensor Ambiental',
      icon: '🌡️',
      keyEntities: ['temperature'],
    },
    {
      id: 'esp32-lab',
      name: 'ESP32 Lab',
      location: 'Laboratório Secundário',
      type: 'Sensor de Temperatura',
      icon: '🔬',
      keyEntities: ['temperature'],
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard em Tempo Real</h1>
        <p className="text-gray-600 mt-1">Monitoramento IoT com WebSocket</p>
      </div>

      {/* Grid de Devices */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Meus Devices</h2>
        <DeviceStatusGrid
          devices={devices}
          onDeviceClick={(deviceId) => {
            console.log('Device clicked:', deviceId);
            // Navegar para página de detalhes
          }}
          columns={3}
        />
      </div>

      {/* Cards Grandes */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Telemetrias Principais</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <RealtimeTelemetryCard
            deviceId="esp32s3-lab"
            entityId="temperature"
            entityName="Temperatura Lab"
            unit="°C"
            icon="🌡️"
            minValue={0}
            maxValue={50}
            warningThreshold={30}
            dangerThreshold={40}
          />

          <RealtimeTelemetryCard
            deviceId="esp32-lab"
            entityId="temperature"
            entityName="Temperatura Sala"
            unit="°C"
            icon="🏠"
            minValue={0}
            maxValue={50}
          />

          <RealtimeTelemetryCard
            deviceId="esp32s3-lab"
            entityId="button"
            entityName="Botão"
            icon="🔘"
          />
        </div>
      </div>

      {/* Cards Compactos */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Resumo Rápido</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <RealtimeTelemetryCardCompact
            deviceId="esp32s3-lab"
            entityId="temperature"
            entityName="Temp. Lab"
            unit="°C"
            icon="🌡️"
          />
          
          <RealtimeTelemetryCardCompact
            deviceId="esp32-lab"
            entityId="temperature"
            entityName="Temp. Sala"
            unit="°C"
            icon="🏠"
          />

          <RealtimeTelemetryCardCompact
            deviceId="esp32s3-lab"
            entityId="led"
            entityName="LED Status"
            icon="💡"
          />

          <RealtimeTelemetryCardCompact
            deviceId="esp32s3-lab"
            entityId="button"
            entityName="Botão"
            icon="🔘"
          />
        </div>
      </div>

      {/* Gráfico */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Histórico em Tempo Real</h2>
        <RealtimeChart
          deviceId="esp32s3-lab"
          entities={[
            { entityId: 'temperature', entityName: 'Temperatura', color: '#ef4444' },
          ]}
          maxDataPoints={30}
          refreshInterval={2000}
          height={400}
          title="Temperatura - ESP32-S3 Lab"
          unit="°C"
        />
      </div>
    </div>
  );
}
